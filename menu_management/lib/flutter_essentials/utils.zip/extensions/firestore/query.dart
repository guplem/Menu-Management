import "package:cloud_firestore/cloud_firestore.dart";

extension QueryExtensions on Query {
  Stream<Set<T>> stream<T>() {
    return (snapshots() as Stream<QuerySnapshot<T>>).map((event) => event.docs.map((doc) => doc.data()).toSet());
  }

  Future<Set<T>> future<T>() async {
    return (await get()).docs.map((doc) => doc.data() as T).toSet();
  }
}