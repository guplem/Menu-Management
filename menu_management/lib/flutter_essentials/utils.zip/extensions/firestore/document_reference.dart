import "package:cloud_firestore/cloud_firestore.dart";

extension DocumentReferenceExtensions on DocumentReference {
  Stream<T?> stream<T>() {
    return (snapshots() as Stream<DocumentSnapshot<T>>).map((event) => event.data());
  }

  Future<T?> future<T>() async {
    return ((await get()) as DocumentSnapshot<T>).data();
  }
}