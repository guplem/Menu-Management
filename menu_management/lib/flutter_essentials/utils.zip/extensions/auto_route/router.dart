import "package:auto_route/auto_route.dart";
import "package:flutter/scheduler.dart";
import "package:flutter/widgets.dart";

extension StackRouterExtensions on StackRouter {
  // TODO: Add into the AutoRouterX extension on BuildContext class from AutoRouter (file auto_router_x.dart), do a PR

  void popUntilPoppedRouteWithName(String routeName) {
    bool pagePopped = false;
    popUntil((Route route) {
      bool wasPopped = pagePopped;
      pagePopped = route.settings.name == routeName;
      return wasPopped;
    });
  }

  void popNextFrame<T extends Object?>([T? result]) {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      pop(result);
    });
  }
}
